/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE IF NOT EXISTS `bd_test` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `bd_test`;

CREATE TABLE IF NOT EXISTS `example` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `example` DISABLE KEYS */;
INSERT INTO `example` (`id`, `name`, `description`) VALUES
	(1, 'prueba', 'descripcion de pruebas'),
	(2, 'test', 'description for test'),
	(3, 'test 3', 'description for test 3'),
	(4, 'test 4', 'description for test 4');
/*!40000 ALTER TABLE `example` ENABLE KEYS */;

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `price` double NOT NULL,
  `mrp` double NOT NULL,
  `stock` int(11) NOT NULL,
  `isPublished` tinyint(1) NOT NULL COMMENT '0=false y 1=true',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `price`, `mrp`, `stock`, `isPublished`) VALUES
	(1, 'Producto 1', 50, 25, 6, 0),
	(2, 'Producto 2', 100, 230, 20, 0),
	(3, 'Producto 3', 200, 230, 0, 0),
	(4, 'Producto 4', 350, 20, 20, 0),
	(5, 'Producto 5', 360, 50, 0, 0),
	(6, 'Producto 6', 100, 200, 0, 0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
